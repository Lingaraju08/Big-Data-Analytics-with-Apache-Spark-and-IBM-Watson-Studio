This folder contains images files referenced by this repository.

[Image Source here](http://chipset-cost.eu/wp-content/uploads/2019/05/Apostolos-Papadopoulos-Spark-Slides.pdf)
